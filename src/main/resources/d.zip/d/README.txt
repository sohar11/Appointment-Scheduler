JAVA APPLICATION

This application facilitates the Scheduling operations of a business that operates across different timezones, countries, and languages.

Author: Shane O'Hara    contact: sohar11@wgu.edu

Application version 1.0 3/28/2023

How to Run program:
1. open project in Intellij
2. Run MainApplication.java
3. Login with username and password contained within the SQL database.
4. Navigate through menus to view reports, add/modify customers and appointments, etc.


Additional Report A3F:
The additional report for this application enables one to view customers by Country. This report can be viewed in the third table of the reports page.







mysql-connector-java-8.0.32
JAVA SE 17.0.1
JavaFX-SDK-17.0.1



IntelliJ IDEA 2022.3.1 (Community Edition)
Build #IC-223.8214.52, built on December 20, 2022
Runtime version: 17.0.5+1-b653.23 amd64
VM: OpenJDK 64-Bit Server VM by JetBrains s.r.o.
Windows 11 10.0
GC: G1 Young Generation, G1 Old Generation
Memory: 984M
Cores: 8
Non-Bundled Plugins:
    com.intellij.properties.bundle.editor (223.7571.203)

Kotlin: 223-1.7.21-release-272-IJ8214.52

