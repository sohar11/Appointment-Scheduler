package com.example.d.model;

/**creates a User class to link with Users within the SQL database*/
public  class User {

    /**userid number*/

    private String userId;

    /**username for logging in*/

    private String userName;

    /**password for logging in*/

    private String password;

}
